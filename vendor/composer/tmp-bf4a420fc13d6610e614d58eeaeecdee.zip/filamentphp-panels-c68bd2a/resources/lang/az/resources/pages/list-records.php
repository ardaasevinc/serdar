<?php

return [

    'breadcrumb' => 'List',

];
