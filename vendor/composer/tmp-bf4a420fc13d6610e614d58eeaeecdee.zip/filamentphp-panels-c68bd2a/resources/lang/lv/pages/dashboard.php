<?php

return [

    'title' => 'Panelis',

];
